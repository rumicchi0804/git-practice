# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'e0d29fa88897668ad303f57c7899d854eb4b62070716a497b46d52df0c5b84c061ebd79ddd62e63b7b7b5d38fb4abc8791d4abe53e6e935020bbedbbdebdcdb8'